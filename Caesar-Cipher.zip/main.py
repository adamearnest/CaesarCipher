#Adam Earnest
#Cu denver
  
#define the encryption function
def encryption(ShiftKey, Message):

  # initialize the encrypted message variable
    EncryptedMessage = ''

  # loop through each letter in the message 
    for letter in Message:
        if letter == ' ':
            EncryptedMessage += ' '
        else:  # if the letter is not a space then make the shift
            newLetter = ord(letter) + ShiftKey
            if newLetter > 90:
                newLetter = newLetter - 26
            EncryptedMessage += chr(newLetter)

    print('The original message was:', Message , " Your encrypted message is:" , EncryptedMessage)  
#call the decryption function and pass the encrypted message and the shift key paramaters
    decryption(ShiftKey, EncryptedMessage)



  #define the decryption function
def decryption(ShiftKey, EncryptedMessage):
  # initialize the decrypted message variable
    DecryptedMessage = ''

  # loop through each letter in the message 
    for letter in EncryptedMessage:
        if letter == ' ':
            DecryptedMessage += ' '
        else:   # if the letter is not a space then make the shift back
            newLetter = ord(letter) - ShiftKey
            if newLetter < 65:
                newLetter = newLetter + 26
            DecryptedMessage += chr(newLetter)
#display the decrypted message
    print('The original message was:', EncryptedMessage , " Your decrypted message is:" , DecryptedMessage)



#define main function 
def main():
  # intiialize shift key variable and find out how far the user wants to shift the letter
   ShiftKey = input('How far would you like to shift the alphabet? ')
   ShiftKey = int(ShiftKey)
   # ask the user for a message to encrypt
   Message = input('What message would you like to encrypt? ')
   # change the message to all upper case
   Message = Message.upper()

#call the encryption function and pass the shift key and message paramaters
   encryption(ShiftKey, Message)
#call the main function
main()